﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SimTheme_Park_Online.Data
{
    public static class TPWConstants
    {
        public static readonly byte[] Bc_Header = new byte[2] { (byte)'B', (byte)'c' };
        public static readonly byte[] Bs_Header = new byte[2] { (byte)'B', (byte)'s' };
    }
}
