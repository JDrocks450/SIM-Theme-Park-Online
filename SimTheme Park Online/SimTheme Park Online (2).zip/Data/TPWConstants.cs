﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SimTheme_Park_Online.Data
{
    public static class TPWConstants
    {
        public static readonly byte[] Bc_Header = new byte[2] { (byte)'B', (byte)'c' };
        public static readonly byte[] Bs_Header = new byte[2] { (byte)'B', (byte)'s' };

        public struct TPWServerListConstants
        {
            public const string I4 = "i4",
                                UZ = "uz",
                                ZU = "zu",
                                F4 = "f4",
                                BG = "bg",
                                dt = "dt",
                                XX = "xx";
            public static string GetDataTypeByType<T>(T Data)
            {
                if (Data is uint)
                    return I4;
                if (Data is float)
                    return F4;
                if (Data is string)
                    return UZ;
                if (Data is byte[])
                    return BG;
                if (Data is long)
                    return ZU;
                if (Data is DateTime)
                    return dt;
                return XX;
            }
        }

        public enum TPWServerListType : uint
        {
            LOGICAL_SERVERS = 0x07,
            THEME_INFO = 0x08,
            CHAT_INFO = 0x02,
            CITY_INFO = 0x01
        }
    }
}
