﻿using QuazarAPI;
using QuazarAPI.Networking.Data;
using QuazarAPI.Networking.Standard;
using System;
using System.IO;
using System.Linq;
using System.Net.Sockets;

namespace SimTheme_Park_Online
{
    public class CityServer : Component
    {
        uint MessageDirectorID;

        public CityServer(int port) : base("CityServer", port, SIMThemeParkWaypoints.CityServer)
        {
            
        }

        protected override void OnIncomingPacket(uint ID, TPWPacket Data)
        {
            if (!HandleCommand(ID, Data))
            {
                if (Data.PacketQueue == 14) // fifth and final packet accounted for
                {
                    var packets = TPWPacket.ParseAll(
                        "Library\\City\\CityServer-ThemeInfo.dat",
                        "Library\\City\\CityServer-LogicalServerInfo.dat",
                        "Library\\City\\CityServer-RideInfo.dat",
                        "Library\\City\\CityServer-ChatParksInfo.dat",
                        "Library\\City\\CityServer-CityInfo.dat"
                        ).ToArray();
                    var cityPacket = GetCityInfoPacket(out _);
                    Send(ID,
                        GetThemeInfoPacket(),
                        GetLogicalServerPacket(),
                        packets[2],
                        GetChatInfoPacket(),
                        cityPacket
                    );
                }
            }
        }

        private TPWPacket GetChatInfoPacket()
        {
            return Factory.TPWPacketFactory.GenerateChatParkInfoPacket(
                    new Data.Structures.TPWChatParkInfoStructure(
                    "Jeremy", "admin@bullfrog.com", 1, new byte[] { 00, 00, 00, 00 }, "SPACE", "Bisquick's Kingdom",
                    0x01, 0x00, 0x10, 0x0A, 0x0B, 0, DateTime.Now, 0x0C, 0x0D, 0x0E, 0x0F, 0x09),
                    new Data.Structures.TPWChatParkInfoStructure(
                    "Jeremy", "admin@bullfrog.com", 1, new byte[] { 00, 00, 00, 00 }, "SPACE", "Bisquick's Kingdom",
                    0x00, 0x00, 0x00, 0x00, 0x00, 0, DateTime.Now, 0x00, 0x00, 0x00, 0x00, 0x00),
                    new Data.Structures.TPWChatParkInfoStructure(
                    "Jeremy", "admin@bullfrog.com", 1, new byte[] { 00, 00, 00, 00 }, "SPACE", "Bisquick's Kingdom",
                    0x01, 0x00, 0x10, 0x0A, 0x0B, 0, DateTime.Now, 0x0C, 0x0D, 0x0E, 0x0F, 0x09),
                    new Data.Structures.TPWChatParkInfoStructure(
                    "Jeremy", "admin@bullfrog.com", 1, new byte[] { 00, 00, 00, 00 }, "SPACE", "Bisquick's Kingdom",
                    0x01, 0x00, 0x10, 0x0A, 0x0B, 0, DateTime.Now, 0x0C, 0x0D, 0x0E, 0x0F, 0x09),
                    new Data.Structures.TPWChatParkInfoStructure(
                    "Jeremy", "admin@bullfrog.com", 1, new byte[] { 00, 00, 00, 00 }, "SPACE", "Bisquick's Kingdom",
                    0x01, 0x00, 0x10, 0x0A, 0x0B, 0, DateTime.Now, 0x0C, 0x0D, 0x0E, 0x0F, 0x09)
                );
        }

        public static TPWPacket GetCityInfoPacket(out Data.Templating.TPWDataTemplate Template) => Factory.TPWPacketFactory.GenerateCityInfoPacket(
            out Template,
            new Data.Structures.TPWCityInfoStructure(0x0A, "HELLO", "WORLD", 100, 50, 50, 0x0B, 0x0C, 0x0D, "BISQUICK", 0x01, 0x0F),
            new Data.Structures.TPWCityInfoStructure(0x0B, "BLOATY", "WORLD", 100, 70, 20, 0x20, 0x03, 0x05, "BULLFROG", 0x01, 0x10));

        private TPWPacket GetLogicalServerPacket() => Factory.TPWPacketFactory.GenerateLogicalServerPacket(
            0x0A, "SERVER1", 0x0B, "SERVERB", 0x0C, 0x0D, "SERVERC", "SERVERD", 0x0E, "SERVERE");
            
        private TPWPacket GetThemeInfoPacket() => Factory.TPWPacketFactory.GenerateThemeInfoPacket(
            "SPACE", "JUNGLE", "FANTASY", out Data.TPWServersideList List);

        public override void Start()
        {
            QConsole.WriteLine(Name, "Starting...");
            BeginListening();
        }

        protected override void OnClientConnect(TcpClient Connection, uint ID)
        {
            base.OnClientConnect(Connection, ID);
        }

        public override void Stop()
        {
            QConsole.WriteLine(Name, "Stopping...");
            StopListening();
        }
    }
}
